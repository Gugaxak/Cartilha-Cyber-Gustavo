### Index

* [Databases](#databases)
* [iOS](#ios)
* [Language Agnostic](#language-agnostic)


### Databases

* [Podcast] - [DatabaseCast](http://databasecast.com.br)


### iOS

* [Podcast] - [CocoaHeads](http://www.cocoaheads.com.br/podcasts)


### Language Agnostic

* [Podcast] - [DevNaEstrada](http://devnaestrada.com.br)
* [Podcast] - [Grok Podcast](http://www.grokpodcast.com)
* [Podcast] - [Hipsters Ponto Tech](http://hipsters.tech)
* [Podcast] - [Lambda3](https://blog.lambda3.com.br/category/podcast/)
* [Podcast] - [PODebug](http://www.podebug.com)
