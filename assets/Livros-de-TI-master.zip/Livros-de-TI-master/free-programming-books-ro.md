### Index

* [Ajax](#ajax)
* [CSS](#css)
* [HTML](#hmtl)
* [JavaScript](#javascript)
* [MySQL](#mysql)
* [PHP](#php)
* [XHTML](#xhtml)


### Ajax

* [Ajax](http://etutoriale.ro/articles/1483/1/Tutorial-Ajax/)


### CSS

* [CSS](http://www.tutorialeweb.net/css/)


### HMTL

* [HTML](http://tutorialehtml.com/ro/introducere-in-html/)


### JavaScript

* [JavaScript](http://www.tutorialeweb.net/javascript/)


### MySQL

* [MySQL](http://profs.info.uaic.ro/~busaco/teach/courses/net/docs/mysql-ro.pdf) (PDF)


### PHP

* [PHP](http://www.tutorialeweb.net/php/)
* [PHP](http://php.punctsivirgula.ro)


### XHTML

* [XHTML](http://www.tutorialeweb.net/xhtml/)
